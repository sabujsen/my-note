const Download = require("sp-download").Download;
var spauth = require("node-sp-auth");
var request = require("request-promise");
const fs = require("fs");

//let dataLoad = ["360 Control", "Balance%20Consolidation"]; //
let dataLoad = ["Balance%20Consolidation"]; ////
dataLoad.forEach((element) => {
  spauth
    .getAuth("http://solutions.pscu.net/", {
      username: "FLesSud@pscu.com",
      password: "Hjkj1188!!",
      domain: "sp",
    })
    .then((data) => {
      let headers = data.headers;
      headers["Accept"] = "application/json;odata=verbose";
      let requestOpts = data.options;
      requestOpts.json = true;
      requestOpts.headers = headers;

      //'DYOC  Design Your Own Card'
      //http://solutions.pscu.net/OurSolutions/ATM%20ATM%20Terminal%20Driving/ATM%20Presentation%20Material/2011%20AE%20Transaction%20Verification.ppt
      //http://solutions.pscu.net/OurSolutions/_api/web/lists/getbytitle('Automated Fraud Alerts (AFA)')/Files
      requestOpts.url =
        "http://solutions.pscu.net/OurSolutions/_api/web/lists/getbytitle('DYOC - Design Your Own Card')/Files";
      let f = [];
      return request.get(requestOpts).then((response) => {
        f.push(response.d.results);
        return response.d.results;

        /*   console.log(response.d.results[1].ParentList);
       console.log(response.d.results[1].AttachmentFiles); */
        // FileSystemObjectType: 1, 0=>File 1=> folder
      });
    })
    .then((dd) => {
      dd.forEach((itm) => {
        if (itm.__metadata.type === "MS.FileServices.File") {
          const download = new Download({
            username: "FLesSud@pscu.com",
            password: "Hjkj1188!!",
            domain: "sp",
          });
          const filePathToDownload = itm.Url;
          const folders = filePathToDownload.split("/");
          const rfolder = folders[folders.length - 3];
          const folder = folders[folders.length - 2];
          const filee = folders[folders.length - 1];
          console.log("folder", folder);
          //const saveToPath1 = `./d2/${folder}`;
          const saveToPath1 = `./d3`;
          try {
            if (fs.existsSync(saveToPath1)) {
              console.log("Directory exists.");
            } else {
              console.log("Directory does not exist.");
              fs.mkdir(saveToPath1, function (err) {
                if (err) {
                  console.log(err);
                } else {
                  console.log("New directory successfully created.");
                }
              });
            }
          } catch (e) {
            console.log("An error occurred.", e);
          }

          //let filePathToDownload = 'https://contoso.sharepoint.com/sites/site/lib/folder/file.ext';
          let saveToPath = saveToPath1; //"./d";

          download
            .downloadFile(filePathToDownload, saveToPath)
            .then((savedToPath) => {
              console.log(
                `${filePathToDownload} has been downloaded to ${savedToPath}`
              );
            })
            .catch((error) => {
              console.log(error);
            });
        }
      });
    });
});
