import { Router } from 'express';
import Route from '@interfaces/routes.interface';
import UserAgentProfileController from '@controllers/UserAgentProfileController';
import { autoInjectable } from 'tsyringe';

@autoInjectable()
class UserAgentProfileRoute implements Route {
    public getUserAgentProfilePath = '/api/users/agent/profile/detail';
    public createUserAgentProfilePath = '/api/users/agents/profile/add';
    public updateUserAgentProfilePath = '/api/users/agents/profile/update';
    public router = Router();
    public userAgentProfileController: UserAgentProfileController;
    constructor(userAgentProfileController: UserAgentProfileController) {
        this.userAgentProfileController = userAgentProfileController;
        this.initializeRoutes();
    }

    private initializeRoutes() {
        this.router.get(`${this.getUserAgentProfilePath}`, this.userAgentProfileController.getUserAgentDetail);
        this.router.post(`${this.createUserAgentProfilePath}`, this.userAgentProfileController.createUserAgentProfile);
        this.router.put(`${this.updateUserAgentProfilePath}`, this.userAgentProfileController.updateUserAgentProfile);
    }
}

export default UserAgentProfileRoute;