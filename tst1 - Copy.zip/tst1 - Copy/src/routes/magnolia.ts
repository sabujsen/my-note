import { Router } from 'express';
import Route from '@interfaces/routes.interface';
import MangnoliaFileManagerController from '@controllers/MagnoliaFileManagerController';
import { autoInjectable } from 'tsyringe';

@autoInjectable()
class MagnoliaFileManagerRoute implements Route {
  public path = '/api/magnolia-filemanager';
  public router = Router();
  public magnoliaFileManagerController: MangnoliaFileManagerController;
  constructor(magnoliaFileManagerController: MangnoliaFileManagerController) {
    this.magnoliaFileManagerController = magnoliaFileManagerController;
    this.initializeRoutes();
  }

  private initializeRoutes() {
    //this.router.post(`${this.path}/get`, this.magnoliaFileManagerController.get);
    this.router.post(`${this.path}/uploadFile`, this.magnoliaFileManagerController.uploadFile);
    this.router.get(`${this.path}/uploadFileSP`, this.magnoliaFileManagerController.uploadFileSP);
    this.router.post(`${this.path}/download`, this.magnoliaFileManagerController.download);
    
  }
}

export default MagnoliaFileManagerRoute;
