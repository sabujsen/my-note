import { Router } from 'express';
import Route from '@interfaces/routes.interface';
import UploadertController from '@controllers/uploaderController';
import { autoInjectable } from 'tsyringe';

@autoInjectable()
class UploaderRoute implements Route {
 
    public uiUploadPath = '/api/uploader/uiUpload';
    public sharepointUploadPath = '/api/uploader/sharepointUpload';


    public router = Router();
    public uploadertController: UploadertController;
    constructor(uploadertController: UploadertController) {
        this.uploadertController = uploadertController;
        this.initializeRoutes();
    }

    private initializeRoutes() {
        this.router.get(`${this.uiUploadPath}`, this.uploadertController.uiUpload);
        this.router.get(`${this.sharepointUploadPath}`, this.uploadertController.sharepointUpload);
    }
}

export default UploaderRoute;
