import { Router } from 'express';
import Route from '@interfaces/routes.interface';
import MagnoliaUploadController from '@controllers/MagnoliaUploadController';
import { autoInjectable } from 'tsyringe';

@autoInjectable()
class MagnoliaUploadRoute implements Route {
    public magnoliaUploadPath = '/api/magnoliaupload/upload';

    public router = Router();
    public magnoliaUploadController: MagnoliaUploadController;
    constructor(magnoliaUploadController: MagnoliaUploadController) {
        this.magnoliaUploadController = magnoliaUploadController;
        this.initializeRoutes();
    }

    private initializeRoutes() {
        this.router.get(`${this.magnoliaUploadPath}`, this.magnoliaUploadController.footerList);
    }
}

export default MagnoliaUploadRoute;
