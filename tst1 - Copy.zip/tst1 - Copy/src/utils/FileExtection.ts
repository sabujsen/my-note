import config from "@config/endpoints.config";

/* const videos = [".mp4", ".mov", ".avi"];
const audios = [".mp3"];
const texts = [".txt", ".doc", ".docx", ".ppt", ".pdf", ".pptx",".xls",".xlsx"];
const images = [".jpg", ".jpeg",".png",".psd"]; */

const videos = config.Videos_Ext;
const audios = config.Audio_Ext;
const texts = config.Text_Ext;
const images = config.Images_Ext;

const handleExtention = (fileExt) => {
  const fileExtLower = fileExt.toLowerCase();

  if (videos.indexOf(fileExtLower) > -1) {
    return DownloadFolder.Videos;
  } else if (audios.indexOf(fileExtLower) > -1) {
    return DownloadFolder.Audios;
  } else if (images.indexOf(fileExtLower) > -1) {
    return DownloadFolder.Images;
  } else if (texts.indexOf(fileExtLower) > -1) {
    return DownloadFolder.Documents;
  } else {
    return DownloadFolder.Others;
  }
};
class DownloadFolder {
  // Create new instances of the same class as static attributes
  static Videos = new DownloadFolder("Videos")
  static Audios = new DownloadFolder("Audios")
  static Images = new DownloadFolder("Images")
  static Documents = new DownloadFolder("Documents")
  static Others = new DownloadFolder("Others")
  name
  constructor(name) {
    this.name = name
  }
}
export { handleExtention,DownloadFolder };
