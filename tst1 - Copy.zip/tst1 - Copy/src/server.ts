import 'reflect-metadata';
import 'dotenv/config';
import 'dotenv-expand';
import App from './app';
import { container } from 'tsyringe';
import MagnoliaFileManagerRoute from './routes/magnolia';
import BookMarkRoute from './routes/bookmark';
import UserAgentProfileRoute from './routes/userAgentProfile';
import FooterRoute from './routes/footer';

import MagnoliaUploadRoute from './routes/magnoliaUpload';
import UploaderRoute from './routes/uploader';

//const indexRoute = container.resolve();
// const express = require('express')
// const app = express();
// app.get('/', (req, res)=>{
//     res.send('home page yyy')
// })
// app.get('/api/bookmark', (req, res)=>{
//     res.send('bookmark');
// })

// app.listen(3000, ()=>{
//     console.log('started server');
// });


const magnoliaFileManager = container.resolve(MagnoliaFileManagerRoute);
const bookmark = container.resolve(BookMarkRoute);
const userAgentProfile = container.resolve(UserAgentProfileRoute);
const footer = container.resolve(FooterRoute);
const magnoliaUploadRoute = container.resolve(MagnoliaUploadRoute);
const uploaderRoute = container.resolve(UploaderRoute);

const app = new App([bookmark,userAgentProfile,footer,magnoliaFileManager,magnoliaUploadRoute,uploaderRoute]);
app.listen()