import { TokenHelper } from "@utils/TokenHelper";
import { injectable } from "tsyringe";
import { AccountSummaryDTO } from "@models/accountsummary.models";
import { logger } from "@utils/logger";
import { Request, Response } from "express";
import { CacheWrapperService } from '@utils/CacheWrapperService';

@injectable()
export class AccountService {
    tokenHelper: TokenHelper;
    cache: CacheWrapperService = CacheWrapperService.getInstance();

    constructor(tokenHelper: TokenHelper) {
        this.tokenHelper = tokenHelper;
    }
    /**
     * Account summary is now an aggregate at company level
     * control accounts add up and 
     * @returns 
     */
    public async getSummary(req: Request) {
        let response: AccountSummaryDTO;
        let allAccounts = []
        const { guid } = req.body;

        // //From the cache make sure to retrieve all the information
        // const model = <CacheModel>this.cache.get(guid); //if you don't have a GUID throw an error

        // //if cache is empty or if guid is empty throw error
        // if (isEmpty(guid) || isEmpty(model)) {
        //     throw new GenericException(403, 'Unable to complete the request');
        // }

       // allAccounts = [...model.control_account, ...model.individual_payaccount];
      //  response = await this.getAggregateValues(allAccounts, model.x_client_id);

        return response;
    }
    
    async getAggregateValues(allAccounts: any, x_client_id: string | string[]) {
        let accessToken = await this.tokenHelper.getAccessToken();
        let axios = await this.tokenHelper.getAxiosInstance();

        let aggregateCurrBal: number = 0;
        let aggregateAvailableCreditAmount: number = 0;
        let aggregateStatementBalance: number = 0;
        let aggregateminimumPaymentDue: number = 0;
        let companyDueDate: string = '';
        if (allAccounts) {
            let promises = []
            for (const account of allAccounts) {
                const configs = {
                    headers: {
                        'Authorization': accessToken,
                        'Accept': 'application/json',
                        'x-client-id': x_client_id,
                        'x-account-number': account,
                        'X-IBM-Client-Id': ""
                    }
                };
                promises.push(axios.get("", configs).then((result: { data: { accountsCreditsSummary: any[]; }; }) => {
                    result.data.accountsCreditsSummary.forEach(resp => {
                        aggregateCurrBal = aggregateCurrBal + parseFloat(resp.accountInfo.currentBalanceAmount);
                        aggregateAvailableCreditAmount = aggregateAvailableCreditAmount + parseFloat(resp.accountSettings.creditLimitAmount);
                        aggregateStatementBalance = aggregateStatementBalance + parseFloat(resp.statementInfo.lastStatementBalance);
                        aggregateminimumPaymentDue = aggregateminimumPaymentDue + parseFloat(resp.accountInfo.minimumPaymentDue);
                        companyDueDate = resp.payments.paymentDueDate;
                    });
                }));
            }
            try {
                await Promise.all(promises)
            } catch (error) {
               // throw new GenericException(403, 'unable to retrieve account summary')
            }

        }//end if
        return {
            currentBalance: aggregateCurrBal,
            availableCredit: aggregateAvailableCreditAmount,
            statementBalance: aggregateStatementBalance,
            minimumDue: aggregateminimumPaymentDue,
            dueDate: companyDueDate
        }
    }//end method
}