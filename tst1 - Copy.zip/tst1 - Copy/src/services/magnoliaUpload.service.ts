import { TokenHelper } from "@utils/TokenHelper";
import { injectable } from "tsyringe";
import { logger } from "@utils/logger";
import { Request, response, Response } from "express";
import { CacheWrapperService } from "@utils/CacheWrapperService";
import path from "path";
import fs from "fs";
import config from "@config/endpoints.config";
import { DownloadFolder } from "@utils/FileExtection";
import fetch from "node-fetch";
const fsPromises = fs.promises;
import oracledb from "oracledb";

@injectable()
export class MagnoliaUploadService {
  private readonly magnoliaAuthorUrl = process.env.MAGNOLIAAUTHORURL;
  tokenHelper: TokenHelper;
  cache: CacheWrapperService = CacheWrapperService.getInstance();

  constructor(tokenHelper: TokenHelper) {
    this.tokenHelper = tokenHelper;
  }
  private async saveDBObject(localFilePath: string, fileName: string) {
    try {
      let stat = fs.statSync(localFilePath);
      console.log("sending file, size %d", stat.size);

      let buff = fs.readFileSync(localFilePath);
      let base64data = buff.toString("base64");

      const documentExtension = path.extname(fileName).substring(1);
      let documentName = path.basename(localFilePath, documentExtension);
      documentName = documentName.substring(0, documentName.length - 1);
      const documentSize = stat.size;
      const documentMymeType = documentExtension; // await fileTypeFromFile(localFilePath)
      logger.error(
        "base64data ::" +
          base64data +
          "::" +
          JSON.stringify({
            documentExtension,
            documentName,
            documentSize,
            documentMymeType,
          })
      );
      return;
      oracledb.getConnection(
        {
          user: "IP_SERVICES_USER",
          password: "dyG743gdfdglhabfs",
          connectString:
            "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST =phdocloud-scan.pscu.net.test)(PORT = 15210))   )  (CONNECT_DATA = (SERVICE_NAME= mc.dev.001) ) )",
        },
        function (err, connection) {
          if (err) {
            console.error("fff", err.message);
            return;
          }
          // 'bind by position' syntax
          let result = connection.execute(
            `INSERT INTO no_tab1 VALUES (:id, :nm)`,
            [2, "Alison"]
          );
          console.log("Rows inserted: " + result.rowsAffected); // 1
          console.log("ROWID of new row: " + result.lastRowid);

          connection.execute(
            "SELECT * FROM BC_OWNER.bc_user_widget",
            [],
            function (err, result) {
              if (err) {
                console.error(err.message);
                doRelease(connection);
                return;
              }
              console.log(result.metaData);
              console.log(result.rows);
              doRelease(connection);
            }
          );
        }
      );
      function doRelease(connection) {
        connection.release(function (err) {
          if (err) {
            console.error(err.message);
          }
        });
      }
    } catch (err) {}
  }
  public async uploadFiles(req: Request, res: Response) {
    try {
      /*   oracledb.getConnection(
        {
          user: "IP_SERVICES_USER",
          password: "dyG743gdfdglhabfs",
          connectString:
            "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST =phdocloud-scan.pscu.net.test)(PORT = 15210))   )  (CONNECT_DATA = (SERVICE_NAME= mc.dev.001) ) )",
        },
        function (err, connection) {
          if (err) {
            console.error("fff", err.message);
            return;
          }
          connection.execute(
            "SELECT * FROM BC_OWNER.bc_user_widget",
            [],
            function (err, result) {
              if (err) {
                console.error(err.message);
                doRelease(connection);
                return;
              }
              console.log(result.metaData);
              console.log(result.rows);
              doRelease(connection);
            }
          );
        }
      );
      function doRelease(connection) {
        connection.release(function (err) {
          if (err) {
            console.error(err.message);
          }
        });
      }
      return; */
      //read Document Folder

      const directoryPath = path.join(
        __dirname,
        "..",
        config.DownPath,
        DownloadFolder.Documents.name
      );
      console.log("directoryPath", directoryPath);
      //passsing directoryPath and callback function
      const files = await fsPromises.readdir(directoryPath);
      //listing all files using forEach
      /*   files.forEach(function (file) */
      for (let fileName of files) {
        // Do whatever you want to do with the file
        console.log(fileName);
        const localFilePath = path.resolve(directoryPath, fileName);
       await this.uploadFile(localFilePath, fileName);
        //  await this.saveDBObject(localFilePath, fileName);
      }

      //List down all files
      //Call Apis

      return "working";
    } catch (error) {
      res.status(500).send(error);
    }
  }

  public uploadFile = async (localFilePath, fileName) => {
    try {
      const uploadPath = "pscu";
      let stat = fs.statSync(localFilePath);
      console.log("sending file, size %d", stat.size);

      let buff = fs.readFileSync(localFilePath);
      let base64data = buff.toString("base64");

      const documentExtension = path.extname(fileName).substring(1);
      let documentName = path.basename(localFilePath, documentExtension);
      documentName = documentName.substring(0, documentName.length - 1);

      const documentHeight = 100;
      const documentWidth = 100;
      const documentSize = stat.size;

      console.log("readStream", {
        documentExtension,
        documentName,
        documentSize,
        documentWidth,
        documentHeight,
      });

      let fileContent = JSON.stringify({
        name: "jcr:content",
        type: "mgnl:resource",
        path:
          "/" +
          uploadPath +
          "/" +
          documentName +
          "." +
          documentExtension +
          "/" +
          "jcr:content",
        properties: [
          {
            name: "jcr:data",
            type: "Binary",
            multiple: false,
            values: [base64data],
          },
          {
            name: "height",
            type: "Long",
            multiple: false,
            values: [documentHeight],
          },
          {
            name: "width",
            type: "Long",
            multiple: false,
            values: [documentWidth],
          },
          {
            name: "size",
            type: "Long",
            multiple: false,
            values: [documentSize],
          },
          {
            name: "extension",
            type: "String",
            multiple: false,
            values: [documentExtension],
          },
          {
            name: "fileName",
            type: "String",
            multiple: false,
            values: [documentName + "." + documentExtension],
          },
          {
            name: "jcr:mimeType",
            type: "String",
            multiple: false,
            values: ["image/png"],
          },
        ],
      });

      fetch(this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/" + uploadPath, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization:
            "Basic: " + Buffer.from("superuser:superuser").toString("base64"),
        },
        body: JSON.stringify({
          name: documentName + "." + documentExtension,
          path: "/" + uploadPath + "/" + documentName + "." + documentExtension,
          type: "mgnl:asset",
          properties: [
            {
              name: "type",
              type: "String",
              multiple: false,
              values: [documentExtension],
            },
            {
              name: "name",
              type: "String",
              multiple: false,
              values: [documentName],
            },
          ],
        }),
      }).then((response) => {
        if (response.status == 200) {
          fetch(
            this.magnoliaAuthorUrl +
              ".rest/nodes/v1/dam/" +
              uploadPath +
              "/" +
              documentName +
              "." +
              documentExtension,
            {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                Authorization:
                  "Basic: " +
                  Buffer.from("superuser:superuser").toString("base64"),
              },
              body: fileContent,
            }
          ).then((response) => {
            if (response.status == 200) {
              /* res.status(200).send({
                message: `File uploaded successfully.`,
              }); */
            } else {
              /*   res.status(response.status).send({
                message: `Could not upload the file: ${response.error}`,
              }); */
            }
          });
        } else {
          /*  res.status(response.status).send({
            message: `Could not upload the file: ${response.error}`,
          }); */
        }
      });
    } catch (error) {
      console.log("ERROR");
      /*    res.status(500).send({
        message: `Could not upload the file: ${error}`,
      }); */
    }
  };
}
