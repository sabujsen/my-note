import { TokenHelper } from "@utils/TokenHelper";
import { injectable } from "tsyringe";
import { logger } from "@utils/logger";
import { Request, response, Response } from "express";
import { CacheWrapperService } from '@utils/CacheWrapperService';

@injectable()
export class FooterService {
    tokenHelper: TokenHelper;
    cache: CacheWrapperService = CacheWrapperService.getInstance();

    constructor(tokenHelper: TokenHelper) {
        this.tokenHelper = tokenHelper;
    }
    
    public async getFooterList(req: Request, res: Response) {
        try{
            return "working"
        } catch(error) {
            res.status(500).send(error)
        }
    }   

}