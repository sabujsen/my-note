import { TokenHelper } from "@utils/TokenHelper";
import config from '@config/endpoints.config';
import { injectable } from "tsyringe";
import { logger } from "@utils/logger";
import { Request, response, Response } from "express";
import { CacheWrapperService } from '@utils/CacheWrapperService';

@injectable()
export class UserAgentProfileService {
    tokenHelper: TokenHelper;
    cache: CacheWrapperService = CacheWrapperService.getInstance();

    constructor(tokenHelper: TokenHelper) {
        this.tokenHelper = tokenHelper;
    }

    configs = {}

    public async commonHeader(){
        let accessToken = await this.tokenHelper.getAccessToken();
        this.configs = {
            'Authorization': accessToken,
            'Accept': 'application/json',
            'X-client-id': '1',
            'X-application-id': '1111',
            'X-ibm-client-id': config.APICClientId,
        };
    }

    public async getUserAgentProfileDetail(req: Request, res: Response) {
        let response;
        try{
            await this.commonHeader();
            
            let profileId = req.body.profileId;
            let axios = await this.tokenHelper.getAxiosInstance();
            await axios({ method: 'get', url: config.UserAgentProfileURL+'?profile_id='+profileId, headers: this.configs}).then(result=>{
                response = result.data;
            })
        } catch(error) {
            if (error.response.status) {
                logger.error('Error recieved from DG ::' + error.response.status + '::' + JSON.stringify(error.response.data));
            }
            response = error.response.data;
        }
        return response;
    }   

    public async createUserAgentProfile(req: Request, res: Response) {
        let response;
        try{
            await this.commonHeader();

            let axios = await this.tokenHelper.getAxiosInstance();
            await axios({ method: 'post', url: config.UserAgentProfileURL,data: req.body,headers: this.configs})
            .then(result=>{
                response = result.data;
            })
        } catch (error) {
            if (error.response.status) {
                logger.error('Error recieved from DG ::' + error.response.status + '::' + JSON.stringify(error.response.data));
            }
            response = error.response.data;
        }
        return response;
    } 
    
    public async updateUserAgentProfile(req: Request, res: Response) {
        let response;
        try{
            await this.commonHeader();

            let axios = await this.tokenHelper.getAxiosInstance();
            await axios({ method: 'put', url: config.UserAgentProfileURL,data: req.body,headers: this.configs})
            .then(result=>{
                response = result.data;
            })
        } catch (error) {
            if (error.response.status) {
                logger.error('Error recieved from DG ::' + error.response.status + '::' + JSON.stringify(error.response.data));
            }
            response = error.response.data;
        }
        return response;
    }  
}