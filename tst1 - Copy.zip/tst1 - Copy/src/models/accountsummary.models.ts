export interface AccountSummaryDTO {
    currentBalance: number,
    availableCredit: number,
    statementBalance: number,
    dueDate: string,
    minimumDue:number
}





