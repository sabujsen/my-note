import RequestFrom from "@utils/RequestFrom"
export interface UploadFileDTO {
  
  requestFrom: string;
  fileName: string;
  fileContent: string;
  fileTag: string;
  fileSize: number;
  fileType: string;
}

