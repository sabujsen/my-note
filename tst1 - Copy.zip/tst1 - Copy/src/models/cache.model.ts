import { isEmpty } from "class-validator";
import { ESMap, Map } from "typescript";


/**
 * control/sub/individual pay account
 * guid ->
 */
export class CacheModel {
    public guid:string;
    public x_client_id: string;
    public sys:string;
    public prin:string;
    public agent:string;
    public companyId:string;
  

    public stmtDates:string[] = [];
    public control_account:string[] = [];
    public sub_account:string[] = [];
    public individual_payaccount:string[] = [];

   

    constructor() {

    }

}
