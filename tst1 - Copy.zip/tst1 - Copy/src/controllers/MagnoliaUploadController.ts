import { NextFunction, Request, Response } from "express";
import { injectable } from "tsyringe";
import { MagnoliaUploadService } from "@services/magnoliaUpload.service";

@injectable()
class MagnoliaUploadController {
    
    magnoliaUploadService:MagnoliaUploadService;
    constructor(magnoliaUploadService:MagnoliaUploadService) {
        this.magnoliaUploadService = magnoliaUploadService;
    }

    public footerList = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
            let output = await this.magnoliaUploadService.uploadFiles(req, res);
            res.status(200);
            res.json(output);
        } catch (error) {
            next(error);
        }
    }
}

export default MagnoliaUploadController;