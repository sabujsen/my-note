import { NextFunction, Request, Response } from "express";
import { injectable } from "tsyringe";
import { UserAgentProfileService } from "@services/userAgentProfile.service";

@injectable()
class UserAgentProfileController {
    
    userAgentProfileService:UserAgentProfileService;
    constructor(userAgentProfileService:UserAgentProfileService) {
        this.userAgentProfileService = userAgentProfileService;
    }

    public getUserAgentDetail = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
            let output = await this.userAgentProfileService.getUserAgentProfileDetail(req, res);
            res.status(200);
            res.json(output);
        } catch (error) {
            next(error);
        }
    }

    public createUserAgentProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
            let output = await this.userAgentProfileService.createUserAgentProfile(req,res);
            res.status(200);
            res.json(output);
        } catch (error) {
            next(error);
        }
    }

    public updateUserAgentProfile = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
            let output = await this.userAgentProfileService.updateUserAgentProfile(req,res);
            res.status(200);
            res.json(output);
        } catch (error) {
            next(error);
        }
    }
}

export default UserAgentProfileController;