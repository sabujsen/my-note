import { NextFunction, Request, Response } from "express";
import { injectable } from "tsyringe";
import { UploaderService } from "@services/uploader.service";
import { UploadFileDTO } from "@models/uploadFile.model";
import config from "@config/endpoints.config";

@injectable()
class UploaderController {
  uploaderService: UploaderService;
  constructor(uploaderService: UploaderService) {
    this.uploaderService = uploaderService;
  }

  public uiUpload = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      let output;
      //Request to uploadFileObject
      let uploadFileObject = await this.uploaderService.getFileObject(req);
      if (parseInt(config.IS_Magnolia) === 1) {
        //output = await this.uploadFile(documentFullPath, documentName);
      } else {
        output = await this.uploaderService.saveFiletoDB(uploadFileObject);
      }
      res.status(200);
      res.json(output);
    } catch (error) {
      next(error);
    }
  };
  public sharepointUpload = async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      let output;
      let spFiles = await this.uploaderService.getSharePointFiles(req, res);
      //console.log("uploadFileDTO spFiles", spFiles);
      if (spFiles) {
        for (let spFile of spFiles) {
          //console.log("spFile", spFile);         
          if (parseInt(config.IS_Magnolia) === 1) {
            //await this.uploadFile(documentFullPath, documentName);
          } else {
            await this.uploaderService.saveFiletoDB(spFile);
          }
        }
      }
      res.status(200);
      res.json(output);
    } catch (error) {
      next(error);
    }
  };
}

export default UploaderController;
