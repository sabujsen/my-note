import { NextFunction, Request, Response } from "express";
import { injectable } from "tsyringe";
import { FooterService } from "@services/footer.service";

@injectable()
class FooterController {
    
    footerService:FooterService;
    constructor(footerService:FooterService) {
        this.footerService = footerService;
    }

    public footerList = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
        try {
            let output = await this.footerService.getFooterList(req, res);
            res.status(200);
            res.json(output);
        } catch (error) {
            next(error);
        }
    }
}

export default FooterController;