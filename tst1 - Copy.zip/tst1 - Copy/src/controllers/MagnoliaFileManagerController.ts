import e, { NextFunction, Request, Response } from "express";
import { injectable } from "tsyringe";
import { AccountService } from "@services/magnolia.service";
import { FileUploadService } from "../services/fileupload.service";
import axios from "axios";
const { createWriteStream } = require("fs");
import * as stream from "stream";
import * as fs from "fs";
import { promisify } from "util";
import path from "path";
const querystring = require("querystring");
// const { curly } = require("node-libcurl");
import fetch from "node-fetch";
import config from "@config/endpoints.config";

const finished = promisify(stream.finished);
@injectable()
class MangnoliaFileManagerController {
  private readonly magnoliaAuthorUrl = process.env.MAGNOLIAAUTHORURL; // "http://localhost:8080/magnoliaAuthor/"; //"http://phdr220.pscu.net.test:8080/custom-core-dx-project-webapp-1.0-SNAPSHOT/";//
  accountService: AccountService;
  _fileUploadService: FileUploadService;
  constructor(
    accountService: AccountService,
    fileUploadService: FileUploadService
  ) {
    this.accountService = accountService;
    this._fileUploadService = fileUploadService;
  }
/* 
  public uploadFile = async (req, res, next: NextFunction) => {
    try {
      var fileInfo = req.body;
      // prepare content.
      if (
        !fileInfo.fileName ||
        !fileInfo.extension ||
        !fileInfo.file ||
        !fileInfo.path
      ) {
        res.status(400).send({
          message: `Missing parameters`,
        });
      }
      var fileContent = JSON.stringify({
        name: "jcr:content",
        type: "mgnl:resource",
        path: "/noodle-soup/jcr:content",
        properties: [
          {
            name: "jcr:data",
            type: "Binary",
            multiple: false,
            values: [
              "iVBORw0KGgoAAAANSUhEUgAAAHgAAAAeCAYAAADnydqVAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKT2lDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVNnVFPpFj333vRCS4iAlEtvUhUIIFJCi4AUkSYqIQkQSoghodkVUcERRUUEG8igiAOOjoCMFVEsDIoK2AfkIaKOg6OIisr74Xuja9a89+bN/rXXPues852zzwfACAyWSDNRNYAMqUIeEeCDx8TG4eQuQIEKJHAAEAizZCFz/SMBAPh+PDwrIsAHvgABeNMLCADATZvAMByH/w/qQplcAYCEAcB0kThLCIAUAEB6jkKmAEBGAYCdmCZTAKAEAGDLY2LjAFAtAGAnf+bTAICd+Jl7AQBblCEVAaCRACATZYhEAGg7AKzPVopFAFgwABRmS8Q5ANgtADBJV2ZIALC3AMDOEAuyAAgMADBRiIUpAAR7AGDIIyN4AISZABRG8lc88SuuEOcqAAB4mbI8uSQ5RYFbCC1xB1dXLh4ozkkXKxQ2YQJhmkAuwnmZGTKBNA/g88wAAKCRFRHgg/P9eM4Ors7ONo62Dl8t6r8G/yJiYuP+5c+rcEAAAOF0ftH+LC+zGoA7BoBt/qIl7gRoXgugdfeLZrIPQLUAoOnaV/Nw+H48PEWhkLnZ2eXk5NhKxEJbYcpXff5nwl/AV/1s+X48/Pf14L7iJIEyXYFHBPjgwsz0TKUcz5IJhGLc5o9H/LcL//wd0yLESWK5WCoU41EScY5EmozzMqUiiUKSKcUl0v9k4t8s+wM+3zUAsGo+AXuRLahdYwP2SycQWHTA4vcAAPK7b8HUKAgDgGiD4c93/+8//UegJQCAZkmScQAAXkQkLlTKsz/HCAAARKCBKrBBG/TBGCzABhzBBdzBC/xgNoRCJMTCQhBCCmSAHHJgKayCQiiGzbAdKmAv1EAdNMBRaIaTcA4uwlW4Dj1wD/phCJ7BKLyBCQRByAgTYSHaiAFiilgjjggXmYX4IcFIBBKLJCDJiBRRIkuRNUgxUopUIFVIHfI9cgI5h1xGupE7yAAygvyGvEcxlIGyUT3UDLVDuag3GoRGogvQZHQxmo8WoJvQcrQaPYw2oefQq2gP2o8+Q8cwwOgYBzPEbDAuxsNCsTgsCZNjy7EirAyrxhqwVqwDu4n1Y8+xdwQSgUXACTYEd0IgYR5BSFhMWE7YSKggHCQ0EdoJNwkDhFHCJyKTqEu0JroR+cQYYjIxh1hILCPWEo8TLxB7iEPENyQSiUMyJ7mQAkmxpFTSEtJG0m5SI+ksqZs0SBojk8naZGuyBzmULCAryIXkneTD5DPkG+Qh8lsKnWJAcaT4U+IoUspqShnlEOU05QZlmDJBVaOaUt2ooVQRNY9aQq2htlKvUYeoEzR1mjnNgxZJS6WtopXTGmgXaPdpr+h0uhHdlR5Ol9BX0svpR+iX6AP0dwwNhhWDx4hnKBmbGAcYZxl3GK+YTKYZ04sZx1QwNzHrmOeZD5lvVVgqtip8FZHKCpVKlSaVGyovVKmqpqreqgtV81XLVI+pXlN9rkZVM1PjqQnUlqtVqp1Q61MbU2epO6iHqmeob1Q/pH5Z/YkGWcNMw09DpFGgsV/jvMYgC2MZs3gsIWsNq4Z1gTXEJrHN2Xx2KruY/R27iz2qqaE5QzNKM1ezUvOUZj8H45hx+Jx0TgnnKKeX836K3hTvKeIpG6Y0TLkxZVxrqpaXllirSKtRq0frvTau7aedpr1Fu1n7gQ5Bx0onXCdHZ4/OBZ3nU9lT3acKpxZNPTr1ri6qa6UbobtEd79up+6Ynr5egJ5Mb6feeb3n+hx9L/1U/W36p/VHDFgGswwkBtsMzhg8xTVxbzwdL8fb8VFDXcNAQ6VhlWGX4YSRudE8o9VGjUYPjGnGXOMk423GbcajJgYmISZLTepN7ppSTbmmKaY7TDtMx83MzaLN1pk1mz0x1zLnm+eb15vft2BaeFostqi2uGVJsuRaplnutrxuhVo5WaVYVVpds0atna0l1rutu6cRp7lOk06rntZnw7Dxtsm2qbcZsOXYBtuutm22fWFnYhdnt8Wuw+6TvZN9un2N/T0HDYfZDqsdWh1+c7RyFDpWOt6azpzuP33F9JbpL2dYzxDP2DPjthPLKcRpnVOb00dnF2e5c4PziIuJS4LLLpc+Lpsbxt3IveRKdPVxXeF60vWdm7Obwu2o26/uNu5p7ofcn8w0nymeWTNz0MPIQ+BR5dE/C5+VMGvfrH5PQ0+BZ7XnIy9jL5FXrdewt6V3qvdh7xc+9j5yn+M+4zw33jLeWV/MN8C3yLfLT8Nvnl+F30N/I/9k/3r/0QCngCUBZwOJgUGBWwL7+Hp8Ib+OPzrbZfay2e1BjKC5QRVBj4KtguXBrSFoyOyQrSH355jOkc5pDoVQfujW0Adh5mGLw34MJ4WHhVeGP45wiFga0TGXNXfR3ENz30T6RJZE3ptnMU85ry1KNSo+qi5qPNo3ujS6P8YuZlnM1VidWElsSxw5LiquNm5svt/87fOH4p3iC+N7F5gvyF1weaHOwvSFpxapLhIsOpZATIhOOJTwQRAqqBaMJfITdyWOCnnCHcJnIi/RNtGI2ENcKh5O8kgqTXqS7JG8NXkkxTOlLOW5hCepkLxMDUzdmzqeFpp2IG0yPTq9MYOSkZBxQqohTZO2Z+pn5mZ2y6xlhbL+xW6Lty8elQfJa7OQrAVZLQq2QqboVFoo1yoHsmdlV2a/zYnKOZarnivN7cyzytuQN5zvn//tEsIS4ZK2pYZLVy0dWOa9rGo5sjxxedsK4xUFK4ZWBqw8uIq2Km3VT6vtV5eufr0mek1rgV7ByoLBtQFr6wtVCuWFfevc1+1dT1gvWd+1YfqGnRs+FYmKrhTbF5cVf9go3HjlG4dvyr+Z3JS0qavEuWTPZtJm6ebeLZ5bDpaql+aXDm4N2dq0Dd9WtO319kXbL5fNKNu7g7ZDuaO/PLi8ZafJzs07P1SkVPRU+lQ27tLdtWHX+G7R7ht7vPY07NXbW7z3/T7JvttVAVVN1WbVZftJ+7P3P66Jqun4lvttXa1ObXHtxwPSA/0HIw6217nU1R3SPVRSj9Yr60cOxx++/p3vdy0NNg1VjZzG4iNwRHnk6fcJ3/ceDTradox7rOEH0x92HWcdL2pCmvKaRptTmvtbYlu6T8w+0dbq3nr8R9sfD5w0PFl5SvNUyWna6YLTk2fyz4ydlZ19fi753GDborZ752PO32oPb++6EHTh0kX/i+c7vDvOXPK4dPKy2+UTV7hXmq86X23qdOo8/pPTT8e7nLuarrlca7nuer21e2b36RueN87d9L158Rb/1tWeOT3dvfN6b/fF9/XfFt1+cif9zsu72Xcn7q28T7xf9EDtQdlD3YfVP1v+3Njv3H9qwHeg89HcR/cGhYPP/pH1jw9DBY+Zj8uGDYbrnjg+OTniP3L96fynQ89kzyaeF/6i/suuFxYvfvjV69fO0ZjRoZfyl5O/bXyl/erA6xmv28bCxh6+yXgzMV70VvvtwXfcdx3vo98PT+R8IH8o/2j5sfVT0Kf7kxmTk/8EA5jz/GMzLdsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAABypJREFUeNrsmnmMVUUWxn+nGwRaFIyAiKKtIgiizvSMMWIQNS4xOJMRHTWCAbe4jRljMmFQIyZDHDUuuEWNRo2gg04ymBhERxERJS5RQIEWcAGVRUDpprtZmu7+5o93ntZU7u33+vEe3QnvJDe3bp2qW+ecr5ZTpwrKVHKStFZSnT//TOAv0a+0pJhtV5TNv1eoT/D0KnFn6iNppKTuAN3Ktu8StDIl3VFw/wKMA5YDJ0u6uQxwFyAzu7QII/co4A/AV8Aw4FFgerd2KvQEms2sLYW/v5k1dUCAnhldbMceKLEfcCQwBDgE6OtTXiXQCDQAG4FaYE2a7IXqnFKn157oVIANDgQaE2Q8Hngf+B3QD2gCKpC0JngulzRZ0te+4LdIWiTpbP95jaRXJTU5v1nSPEljUoS5TNJ8SdsDJ6JJ0kJJ10vqlkMZkzRK0r2SPpS0W/nTzki37POd/2e3y3KDpDudJ0mt3tbYduQ6X9IbkhqDthZJulpSRUL5ukCu6Qn8WYF8syJeP0kPSvoy0u97STMk1Xi5wW7rhyXd5M8CokpbU4zVKukJBzSNf1Ek2LN5gDDPR02scA9Jt0haHZXfIul+SedIOlRST0lVkqol/VnSnHbaWiVpsaQNUX59O3UmJMj2QA6d5sY65QHwuwH/3SB/qKR1OdprkXSFl58g6X1JL/p7JCoebZHUOxBuvAOfpTrv6TFNiZQ9SVJtQrkXJfXJYwq7NkW+zd4R+nZAp/qwTUkT86z3cJEArpL0TsBrThmETZIO8TrdJQ2SZNmfxPR3ScdKGi1paQJ/qvNHSfok4l0eCT5e0geShgZ5p0WjZnHAOzFlRM3+ReD81ql5KYafngBwm6S/SRriOi+L+JcE//0iyN8laZKkoyWNjWaG7ZL67inAAchzJN0mqVd23fepOKRJacb4P0NGvJqIPyfiD4/4/8gTgJlBnZ+C/E9TgDmmg47IIyn/+VcCwC9HdU+J+JODtTCkhxI6c0jnFQPgdnSM9ZiWVC52cpbm+F4Sufe1knYBPTzrgARBBgEjgapo45+lSi93GFCTIOMPZvZ1B53N41LyFybkLc7xnQ1MDInyYyAWRN/HAm8WyXPuBpwAHNZO7KJ3PgDH+7NWSWHW7oRiOwOAQ6GqgaeAc/PdDqbkV3bQGCcDZyewlgLPAj0T5A91bo50zlJcrz76bsxRvlBwJwL3AAO7TKjS14q3OgAuZvZDSo8/VNIf82y3Bpid0FkWAeeY2c69GYIugh0vBJ4vFNxSxqIvjKa0ycBRwEH+PJlS71IHKKZZkm5N86LdV3gc+NCnsSytB64FRpvZ5j3UKe4cB0Xf8fK0qwh2nBykvwHOAgYEdsxJpQpVhmvgBjO7LwKkd8oorndv0IA/RevgA8C9kmoduBaPZI2IlF0HzAdeAV43s9Yi6bQq+j4z6oxntRNfLpSGBelnzGx+eKjQmQA3BOkBkk43s/eyXipwQcIoHAbcAkxwh2ErMA2YCwx2p2Wgj5RewH4ed10AbAJWAyvMbE2J4sU/S1oKnORZN0ha4c7WCCDsxNuBj1JG82iPG28FtuUIizZ4JwY4T9KjZtboIds7OxPgtyMnaYGkDZ4eENtO0nPAxGjtvM3MslN5LfDfLnAucD8wI7DdEynlnjSzbcH3e8DFnq7x6RZfttrrkG8C13h6DLBZ0o8eh8/LiasoUW9fDDwTO0sBuLui6XdSgmM0VdIVkg7oQqc+M4G7cxR7DZgS5d2R4HXnQ9OALZFnfqS/W4HmfEbw2uC7LqFMLv53wIGe/jnIv873zVcDw4Hu3ltnADuAG71cd6C/v0MaCLwAtEr6AljmU/JKXw9Xm1lDAUZri3Ta1hGdzex2SfOAvwKjff1vBD71Tv1SPO2a2Ur38KcApwZ71hZ/bwza3BjUWyvp98BU35EM8un/Y+Au72yHJ9g+595zr5KkgcB4YCwwKmlfnULrHexVDvxq4EvgmyI6V7lkNzMTXZS6yoF/lTsUm3wqGxA5GmnT9CB/zojymyR9DLwOvGxm35dw2u6y4HbaCJZU6VPOOI86VQdr80LgDd/TLjezOj9o6A8cARwNHAMM9W3E8MDTTKIWYCZwq5ltpUwlBbavpLsSzmQ/l3SVpP0LmSIlHS/pZj+oT6PPshfRylQacH/rtxCSjicri9jOOEk7UkAeU0aidAB/lWDw/5SoradTAB65r9m9Yi+BW+XrZkz1JWirEvhNAuvfZrasPNRKB/IrCSNqd+pNhMLaGBJdccnScx7eK1MJAe4h6TG/JBbTJ37LsrqA/w6WdKWk16I7YG2ed/q+bHfrBKCrgauAi8gE6WPaQuZm/joPZDSRCcm1kQnRVXn0JntT5OCgbnabNReYbWbf7usDyzp5VPcnE7kaQeaIcTCZQHo/BzI+VmxwoDeRCemtJxMqXU7mxsYKM2umTL/Q/wYA29lRLViSXbMAAAAASUVORK5CYII="
            ],
          },
          {
            name: "height",
            type: "Long",
            multiple: false,
            values: ["5"],
          },
          {
            name: "width",
            type: "Long",
            multiple: false,
            values: ["5"],
          },
          {
            name: "extension",
            type: "String",
            multiple: false,
            values: ["png"],
          },
          {
            name: "fileName",
            type: "String",
            multiple: false,
            values: ["noodle-soup.png"],
          },
          {
            name: "jcr:mimeType",
            type: "String",
            multiple: false,
            values: ["image/png"],
          },
        ],
      });

      fetch(this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization:
            "Basic: " + Buffer.from("superuser:superuser").toString("base64"),
        },
        body: JSON.stringify({
          name: "noodle-soup",
          type: "mgnl:asset",
          path: "/noodle-soup",
          properties: [
            {
              name: "type",
              type: "String",
              multiple: false,
              values: ["png"],
            },
            {
              name: "name",
              type: "String",
              multiple: false,
              values: ["noodle-soup"],
            },
            {
              name: "type",
              type: "String",
              multiple: false,
              values: ["png"],
            },
            {
              name: "title",
              type: "String",
              multiple: false,
              values: ["I love noodle soup"],
            },
          ],
        }),
      }).then((response) => {
        if (response.status == 200) {
          fetch(this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/noodle-soup", {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization:
                "Basic: " +
                Buffer.from("superuser:superuser").toString("base64"),
            },
            body: fileContent,
          }).then((response) => {
            if (response.status == 200) {
              res.status(200).send({
                message: `File uploaded successfully.`,
              });
            } else {
              res.status(response.status).send({
                message: `Could not upload the file: ${response.error}`,
              });
            }
          });
        } else {
          res.status(response.status).send({
            message: `Could not upload the file: ${response.error}`,
          });
        }
      });
    } catch (error) {
      console.log("ERROR");
      res.status(500).send({
        message: `Could not upload the file: ${error}`,
      });
    }
  }; */

  public uploadFile = async (req, res, next: NextFunction) => {
    try {
      var fileInfo = req.body;
      // prepare content.
      if (
        !fileInfo.fileName ||
        !fileInfo.extension ||
        !fileInfo.file ||
        !fileInfo.path
      ) {
        res.status(400).send({
          message: `Missing parameters`,
        });
      }
      console.log("fileInfo.file",fileInfo.file)
      let fileContent = JSON.stringify({
        name: "jcr:content",
        type: "mgnl:resource",
        path:
          "/" +
          fileInfo.path +
          "/" +
          fileInfo.fileName +
          "." +
          fileInfo.extension +
          "/" +
          "jcr:content",
        properties: [
          {
            name: "jcr:data",
            type: "Binary",
            multiple: false,
            values: [fileInfo.file],
          },
          {
            name: "height",
            type: "Long",
            multiple: false,
            values: [fileInfo.height],
          },
          {
            name: "width",
            type: "Long",
            multiple: false,
            values: [fileInfo.width],
          },
          {
            name: "size",
            type: "Long",
            multiple: false,
            values: [fileInfo.size],
          },
          {
            name: "extension",
            type: "String",
            multiple: false,
            values: [fileInfo.extension],
          },
          {
            name: "fileName",
            type: "String",
            multiple: false,
            values: [fileInfo.fileName + "." + fileInfo.extension],
          },
          {
            name: "jcr:mimeType",
            type: "String",
            multiple: false,
            values: ["image/png"],
          },
        ],
      });

      fetch(this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/" + fileInfo.path, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization:
            "Basic: " + Buffer.from("superuser:superuser").toString("base64"),
        },
        body: JSON.stringify({
          name: fileInfo.fileName + "." + fileInfo.extension,
          path:
            "/" +
            fileInfo.path +
            "/" +
            fileInfo.fileName +
            "." +
            fileInfo.extension,
          type: "mgnl:asset",
          properties: [
            {
              name: "type",
              type: "String",
              multiple: false,
              values: [fileInfo.extension],
            },
            {
              name: "name",
              type: "String",
              multiple: false,
              values: [fileInfo.fileName],
            },
          ],
        }),
      }).then((response) => {
        if (response.status == 200) {
          fetch(
            this.magnoliaAuthorUrl +
              ".rest/nodes/v1/dam/" +
              fileInfo.path +
              "/" +
              fileInfo.fileName +
              "." +
              fileInfo.extension,
            {
              method: "PUT",
              headers: {
                "Content-Type": "application/json",
                Authorization:
                  "Basic: " +
                  Buffer.from("superuser:superuser").toString("base64"),
              },
              body: fileContent,
            }
          ).then((response) => {
            if (response.status == 200) {
              res.status(200).send({
                message: `File uploaded successfully.`,
              });
            } else {
              res.status(response.status).send({
                message: `Could not upload the file: ${response.error}`,
              });
            }
          });
        } else {
          res.status(response.status).send({
            message: `Could not upload the file: ${response.error}`,
          });
        }
      });
    } catch (error) {
      console.log("ERROR");
      res.status(500).send({
        message: `Could not upload the file: ${error}`,
      });
    }
  };
  public uploadFileSP = async (req, res, next: NextFunction) => {
    try {
      const downloadFolderName = config.DownPath;

      const fileName = "Documents\\j.png"; // `Documents\\ACS Sample Letters 092021.pdf`;
      const localFilePath = path.resolve(
        "C:\\@Node_Repo\\tst1\\src\\utils",
        downloadFolderName,
        fileName
      );
      console.log("dlocalFilePathata :", localFilePath);

      let stat = fs.statSync(localFilePath);

      console.log("dlocalFilePathata :", localFilePath);
      console.log("sending file, size %d", stat.size);

      res.writeHead(200, {
        "Content-Type": "application/x-tar",
        "Content-Disposition": "attachment; filename=" + localFilePath,
        "Content-Length": stat.size,
        "Content-Transfer-Encoding": "binary",
        Authorization:
          "Basic: " + Buffer.from("superuser:superuser").toString("base64"),
      });

      const readStream = fs
        .createReadStream(localFilePath, {
          /*  encoding: "base64", */ encoding: null,
        })
        .pipe(res);
      const data = [];

      /*   await readStream.on("data", (chunk) => {
        data.push(chunk);
       
      }); */

      /*     readStream.on("end", () => {
        console.log("end :", Buffer.concat(data).toString());
        // end : I am transferring in bytes by bytes called chunk
      }); */

      const documentExt = path.extname(fileName);
      const documentName = path.basename(localFilePath, documentExt);

      const documentHeight = 100;
      const documentWidth = 100;
      const documentSize = stat.size;

      console.log("documentName :", documentName);
      console.log(
        "Buffer.concat(data).toString() :",
        readStream.toString("base64")
      );

      const uploadPath = "pscu";
      var fileInfo = req.body;
      /* // prepare content.
      if (
        !fileInfo.fileName ||
        !fileInfo.extension ||
        !fileInfo.file ||
        !fileInfo.path
      ) {
        res.status(400).send({
          message: `Missing parameters`,
        });
      } */
      var fileContent = JSON.stringify({
        name: "jcr:content",
        type: "mgnl:resource",
        path:
          "/" +
          uploadPath +
          "/" +
          documentName +
          "." +
          documentExt +
          "/" +
          "jcr:content",
        properties: [
          {
            name: "jcr:data",
            type: "Binary",
            multiple: false,
            values: [readStream.toString("base64")],
          },
          {
            name: "height",
            type: "Long",
            multiple: false,
            values: [documentHeight],
          },
          {
            name: "width",
            type: "Long",
            multiple: false,
            values: [documentWidth],
          },
          {
            name: "size",
            type: "Long",
            multiple: false,
            values: [documentSize],
          },
          {
            name: "extension",
            type: "String",
            multiple: false,
            values: [documentExt],
          },
          {
            name: "fileName",
            type: "String",
            multiple: false,
            values: [documentName + "." + documentExt],
          },
          {
            name: "jcr:mimeType",
            type: "String",
            multiple: false,
            values: ["image" + "/" + documentExt],
          },
        ],
      });

      fetch(this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/" + uploadPath, {
        method: "PUT",
        /*  headers: {
          "Content-Type": "application/x-tar",
          "Content-Disposition": "attachment; filename=" + localFilePath,
          "Content-Length": stat.size,
          "Content-Transfer-Encoding": "binary",
          Authorization:
            "Basic: " + Buffer.from("superuser:superuser").toString("base64"),
        }, */
        body: JSON.stringify({
          name: documentName + "." + documentExt,
          path: "/" + uploadPath + "/" + documentName + "." + documentExt,
          type: "mgnl:asset",
          properties: [
            {
              name: "type",
              type: "String",
              multiple: false,
              values: [documentExt],
            },
            {
              name: "name",
              type: "String",
              multiple: false,
              values: [documentName],
            },
          ],
        }),
      }).then((response) => {
        if (response.status == 200) {
          fetch(
            this.magnoliaAuthorUrl +
              ".rest/nodes/v1/dam/" +
              uploadPath +
              "/" +
              documentName +
              "." +
              documentExt,
            {
              method: "PUT",
              /*    headers: {
                "Content-Type": "application/x-tar",
                "Content-Disposition": "attachment; filename=" + localFilePath,
                "Content-Length": stat.size,
                "Content-Transfer-Encoding": "binary",
                Authorization:
                  "Basic: " +
                  Buffer.from("superuser:superuser").toString("base64"),
              }, */
              body: fileContent,
            }
          ).then((response) => {
            if (response.status == 200) {
              res.status(200).send({
                message: `File uploaded successfully.`,
              });
            } else {
              res.status(response.status).send({
                message: `Could not upload the file:}`,
              });
            }
          });
        } else {
          res.status(response.status).send({
            message: `Could not upload the file:`,
          });
        }
      });
    } catch (error) {
      console.log("ERROR");
      res.status(500).send({
        message: `Could not upload the file: ${error}`,
      });
    }
  };
  public download = async (req, res) => {
    const fileName = req.body.filePath;
    const response = await axios({
      method: "get",
      url: this.magnoliaAuthorUrl + ".rest/nodes/v1/dam/" + fileName,
      auth: {
        username: "superuser",
        password: "superuser",
      },
    });
    console.log(response.data.name);
    if (response.status == 200) {
      var downloadUrl =
        this.magnoliaAuthorUrl +
        "dam/jcr:" +
        response.data.identifier +
        "/" +
        response.data.name;
      return axios({
        method: "get",
        url: downloadUrl,
        responseType: "stream",
        auth: {
          username: "superuser",
          password: "superuser",
        },
      }).then((response) => {
        const directoryPath = "./";
        const ext = path.extname(fileName);
        const tempFilename = "test" + ext;
        const tempfilepath = directoryPath + tempFilename;
        const writer = createWriteStream(tempfilepath);

        return new Promise((resolve, reject) => {
          response.data.pipe(writer);
          let error = null;
          writer.on("error", (err) => {
            error = err;
            writer.close();
            reject(err);
          });
          writer.on("close", () => {
            if (!error) {
              res.download(tempfilepath, tempFilename, (err) => {
                if (err) {
                  res.status(500).send({
                    message: "Could not download the file. " + err,
                  });
                } else {
                  fs.unlinkSync(tempfilepath);
                }
              });
              resolve(true);
            }
          });
        });
      });
    } else {
      res.status(response.status).send({
        message: `Could not download the file`,
      });
    }
  };
} //end of class

export default MangnoliaFileManagerController;
